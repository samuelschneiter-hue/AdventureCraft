import { Link, createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import {
  Sword, Shield, Gem, Droplets, Wind, Star,
  Coins
} from 'lucide-react'
import items, { type Rarity, type ItemType, rarityConfig, typeLabels } from '@/data/items'

export const Route = createFileRoute('/')({
  component: CatalogPage,
})

const typeIcons: Record<ItemType, React.ElementType> = {
  weapon:     Sword,
  armor:      Shield,
  accessory:  Gem,
  consumable: Droplets,
  mount:      Wind,
  pet:        Star,
}

const ALL_TYPES: Array<{ value: ItemType | 'all'; label: string }> = [
  { value: 'all',        label: 'All' },
  { value: 'weapon',     label: 'Weapons' },
  { value: 'armor',      label: 'Armor' },
  { value: 'accessory',  label: 'Accessories' },
  { value: 'consumable', label: 'Consumables' },
  { value: 'mount',      label: 'Mounts' },
  { value: 'pet',        label: 'Pets' },
]

const ALL_RARITIES: Array<Rarity | 'all'> = ['all', 'common', 'uncommon', 'rare', 'epic', 'legendary']

function ItemArt({ type, rarity }: { type: ItemType; rarity: Rarity }) {
  const cfg = rarityConfig[rarity]
  const Icon = typeIcons[type]

  return (
    <div
      className="item-art"
      style={{
        background: `radial-gradient(circle at 50% 45%, ${cfg.bg} 0%, rgba(13,13,24,0.9) 70%)`,
        borderBottom: `1px solid ${cfg.border}`,
      }}
    >
      <div className="item-art-grid" />
      <div
        className="item-art-icon"
        style={{ filter: `drop-shadow(0 0 18px ${cfg.glow})` }}
      >
        <Icon size={56} color={cfg.color} strokeWidth={1.2} />
      </div>
      {(['tl','tr','bl','br'] as const).map(pos => (
        <div
          key={pos}
          className={`item-art-corner item-art-corner-${pos}`}
          style={{ borderColor: cfg.border }}
        />
      ))}
    </div>
  )
}

function CatalogPage() {
  const [activeType, setActiveType] = useState<ItemType | 'all'>('all')
  const [activeRarity, setActiveRarity] = useState<Rarity | 'all'>('all')

  const filtered = items.filter(item => {
    const typeMatch   = activeType   === 'all' || item.type   === activeType
    const rarityMatch = activeRarity === 'all' || item.rarity === activeRarity
    return typeMatch && rarityMatch
  })

  return (
    <div>
      {/* Header */}
      <header className="catalog-header">
        <div className="catalog-eyebrow">
          <span>&#9670;</span>
          Preview Only — No Purchases
          <span>&#9670;</span>
        </div>
        <h1 className="catalog-title">
          <span>Item Codex</span>
        </h1>
        <p className="catalog-subtitle">
          Browse the complete collection of in-game items — equipment, consumables, mounts, and more.
        </p>
        <div className="catalog-meta">
          <span>{items.length} Items</span>
          <div className="catalog-meta-dot" />
          <span>5 Rarities</span>
          <div className="catalog-meta-dot" />
          <span>6 Categories</span>
        </div>
      </header>

      <div className="catalog-divider" />

      {/* Sticky filter bar */}
      <div className="filter-bar">
        <div className="filter-bar-inner">
          {/* Type filters */}
          <div className="filter-group">
            <span className="filter-label">Type</span>
            {ALL_TYPES.map(t => (
              <button
                key={t.value}
                onClick={() => setActiveType(t.value)}
                className={`filter-pill ${activeType === t.value ? 'active' : ''}`}
                style={activeType === t.value ? {
                  borderColor: 'rgba(139,111,255,0.5)',
                  color: '#c084fc',
                  background: 'rgba(139,111,255,0.1)',
                } : {}}
              >
                {t.label}
              </button>
            ))}
          </div>

          {/* Rarity filters */}
          <div className="filter-group">
            <span className="filter-label">Rarity</span>
            <button
              onClick={() => setActiveRarity('all')}
              className={`filter-pill ${activeRarity === 'all' ? 'active' : ''}`}
              style={activeRarity === 'all' ? {
                borderColor: 'rgba(139,111,255,0.5)',
                color: '#c084fc',
                background: 'rgba(139,111,255,0.1)',
              } : {}}
            >
              All
            </button>
            {(ALL_RARITIES.filter(r => r !== 'all') as Rarity[]).map(r => {
              const cfg = rarityConfig[r]
              const isActive = activeRarity === r
              return (
                <button
                  key={r}
                  onClick={() => setActiveRarity(r)}
                  className="rarity-pip"
                  title={cfg.label}
                  style={{
                    borderColor: isActive ? cfg.color : cfg.border,
                    background:  isActive ? cfg.bg     : 'transparent',
                    color:       cfg.color,
                    boxShadow:   isActive ? `0 0 10px ${cfg.glow}` : 'none',
                    fontFamily:  'var(--font-mono)',
                    fontSize:    '9px',
                  }}
                >
                  {cfg.label[0]}
                </button>
              )
            })}
          </div>
        </div>
      </div>

      {/* Results count */}
      <div className="results-info" style={{ marginTop: '28px' }}>
        {filtered.length === items.length
          ? `Showing all ${items.length} items`
          : `${filtered.length} of ${items.length} items`}
      </div>

      {/* Grid */}
      <div className="items-grid">
        {filtered.length === 0 ? (
          <div className="empty-state">
            <div className="empty-state-title">No items found</div>
            <div className="empty-state-sub">Try adjusting the filters above</div>
          </div>
        ) : (
          filtered.map((item, index) => {
            const cfg = rarityConfig[item.rarity]
            return (
              <Link
                key={item.id}
                to="/products/$productId"
                params={{ productId: item.id.toString() }}
                className="item-card"
                style={{
                  animationDelay: `${index * 40}ms`,
                  '--hover-border': cfg.border,
                  '--hover-shadow': cfg.glow,
                } as React.CSSProperties}
                onMouseEnter={e => {
                  const el = e.currentTarget as HTMLElement
                  el.style.borderColor = cfg.border
                  el.style.boxShadow = `0 8px 32px ${cfg.glow}, 0 0 0 1px ${cfg.border}`
                }}
                onMouseLeave={e => {
                  const el = e.currentTarget as HTMLElement
                  el.style.borderColor = ''
                  el.style.boxShadow = ''
                }}
              >
                <ItemArt type={item.type} rarity={item.rarity} />

                <div className="card-body">
                  <div className="card-rarity" style={{ color: cfg.color }}>
                    <div className="card-rarity-dot" style={{ background: cfg.color, boxShadow: `0 0 6px ${cfg.glow}` }} />
                    {item.rarity === 'legendary'
                      ? <span className="legendary-shimmer">{cfg.label}</span>
                      : cfg.label
                    }
                  </div>
                  <h3 className="card-name">{item.name}</h3>
                  <div className="card-footer">
                    <span className="card-type">{typeLabels[item.type]}</span>
                    <span className="card-price">
                      <Coins size={13} strokeWidth={1.5} />
                      {item.price.toLocaleString()}
                    </span>
                  </div>
                </div>
              </Link>
            )
          })
        )}
      </div>
    </div>
  )
}
