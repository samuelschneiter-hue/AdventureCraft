export type Rarity = 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary'
export type ItemType = 'weapon' | 'armor' | 'accessory' | 'consumable' | 'mount' | 'pet'

export interface Item {
  id: number
  name: string
  type: ItemType
  rarity: Rarity
  shortDescription: string
  description: string
  price: number
  currency: string
  stats: Record<string, string>
}

export const rarityConfig: Record<Rarity, { label: string; color: string; glow: string; border: string; bg: string }> = {
  common:    { label: 'Common',    color: '#b0b0b8', glow: 'rgba(176,176,184,0.25)', border: 'rgba(176,176,184,0.3)', bg: 'rgba(176,176,184,0.06)' },
  uncommon:  { label: 'Uncommon',  color: '#4ade80', glow: 'rgba(74,222,128,0.28)',  border: 'rgba(74,222,128,0.35)',  bg: 'rgba(74,222,128,0.06)'  },
  rare:      { label: 'Rare',      color: '#60a5fa', glow: 'rgba(96,165,250,0.3)',   border: 'rgba(96,165,250,0.4)',   bg: 'rgba(96,165,250,0.06)'  },
  epic:      { label: 'Epic',      color: '#c084fc', glow: 'rgba(192,132,252,0.32)', border: 'rgba(192,132,252,0.4)',  bg: 'rgba(192,132,252,0.07)' },
  legendary: { label: 'Legendary', color: '#f59e0b', glow: 'rgba(245,158,11,0.4)',   border: 'rgba(245,158,11,0.45)', bg: 'rgba(245,158,11,0.08)'  },
}

export const typeLabels: Record<ItemType, string> = {
  weapon:     'Weapon',
  armor:      'Armor',
  accessory:  'Accessory',
  consumable: 'Consumable',
  mount:      'Mount',
  pet:        'Pet',
}

const items: Item[] = [
  {
    id: 1,
    name: 'Shadowfang Blade',
    type: 'weapon',
    rarity: 'legendary',
    shortDescription: 'Forged in the void between worlds, this blade drinks shadow.',
    description: 'Forged in the void between worlds by the Shadow Artificers of the Third Age, Shadowfang absorbs ambient darkness and releases it in devastating strikes. The blade whispers the names of those it has slain — a list that grows with each wielder. Warriors who carry it report their own shadow sometimes moves independently.',
    price: 48500,
    currency: 'Gold',
    stats: { 'Attack Power': '847', 'Crit Chance': '+23%', 'Shadow Damage': '+340', 'Durability': '150/150' },
  },
  {
    id: 2,
    name: 'Ironclad Warplate',
    type: 'armor',
    rarity: 'rare',
    shortDescription: 'Tempered in dragonfire. Built for those who do not retreat.',
    description: 'Each plate was individually tempered in the breath of captive wyverns. The layered construction distributes impact forces across the entire suit, reducing trauma to the wearer during sustained combat. The maker\'s mark is stamped inside the gorget: a hammer above a flame.',
    price: 12800,
    currency: 'Gold',
    stats: { 'Defense': '612', 'Block Chance': '+18%', 'Fire Resistance': '+45%', 'Durability': '200/200' },
  },
  {
    id: 3,
    name: 'Moonweave Amulet',
    type: 'accessory',
    rarity: 'epic',
    shortDescription: 'Woven from light captured during a lunar eclipse.',
    description: 'Harvested during the rare eclipse of the twin moons, this amulet pulses with soft silver light. It enhances the wearer\'s connection to lunar magic cycles and amplifies healing spells cast under open sky. The chain is woven from actual moonlight, preserved by forgotten methods.',
    price: 27300,
    currency: 'Gold',
    stats: { 'Magic Power': '+280', 'Healing Bonus': '+35%', 'Mana Regen': '+12/sec', 'Lunar Affinity': 'Active' },
  },
  {
    id: 4,
    name: 'Swiftfoot Wraps',
    type: 'armor',
    rarity: 'uncommon',
    shortDescription: 'Lightweight binding that refuses to slow the wearer.',
    description: 'Made from the sinew of a cloud stag, these wraps feel like wearing nothing at all. Couriers of the Messenger\'s Guild favor them for long-distance runs through treacherous terrain. The enchantment reduces ground friction by precisely the margin needed for maximum safe speed.',
    price: 3200,
    currency: 'Gold',
    stats: { 'Move Speed': '+22%', 'Dodge Chance': '+8%', 'Defense': '84', 'Durability': '75/75' },
  },
  {
    id: 5,
    name: 'Dawnbreaker Shield',
    type: 'armor',
    rarity: 'legendary',
    shortDescription: 'Blessed by the First Paladin. Radiates holy fire on impact.',
    description: 'This shield was blessed by Valdris, the First Paladin, at the dawn of the Second Era. When struck by enemies of light, it discharges a burst of holy fire that blinds attackers and heals the defender. The crest depicts a sun mid-eclipse — a symbol of power preserved through darkness.',
    price: 52000,
    currency: 'Gold',
    stats: { 'Defense': '920', 'Block Chance': '+32%', 'Holy Damage on Block': '240', 'Durability': '300/300' },
  },
  {
    id: 6,
    name: 'Crimson Mending Draft',
    type: 'consumable',
    rarity: 'common',
    shortDescription: 'A reliable battlefield remedy. Tastes faintly of copper.',
    description: 'Distilled from bloodmoss and cave-grown fungi, this standard-issue healing potion restores vitality quickly. Standard issue among militia units across the eastern provinces. The copper taste is considered a sign of proper preparation — a tasteless batch is likely counterfeit.',
    price: 150,
    currency: 'Gold',
    stats: { 'HP Restored': '+850', 'Cast Time': 'Instant', 'Cooldown': '30 sec', 'Stack Size': '20' },
  },
  {
    id: 7,
    name: 'Voidweave Mantle',
    type: 'armor',
    rarity: 'epic',
    shortDescription: 'Threads pulled from the fabric of a collapsed dimension.',
    description: 'Woven from dimensional filaments extracted from a collapsed pocket dimension, this cloak partially phases the wearer out of normal space. Projectiles and energy blasts pass through at reduced effectiveness. The wearer casts no shadow while wearing it.',
    price: 31500,
    currency: 'Gold',
    stats: { 'Defense': '445', 'Phase Shift': '15% dodge', 'Magic Resistance': '+52%', 'Durability': '120/120' },
  },
  {
    id: 8,
    name: 'Tempest Crystal',
    type: 'accessory',
    rarity: 'rare',
    shortDescription: 'A storm bottled. Handle with dry hands.',
    description: 'This crystal was extracted from the eye of a permanent storm above the Shattered Peaks. It stores electrical charge from ambient lightning and releases it in focused bursts when the wearer casts storm spells. A faint buzzing is normal. A loud crackling is not.',
    price: 9700,
    currency: 'Gold',
    stats: { 'Lightning Damage': '+195', 'Storm Mastery': '+3', 'Charge Capacity': '500 bolts', 'Recharge Rate': '8/sec' },
  },
  {
    id: 9,
    name: 'Ashen Spire Staff',
    type: 'weapon',
    rarity: 'epic',
    shortDescription: 'Carved from a tree struck by volcanic lightning.',
    description: 'The heartwood of an ancient tree that survived a volcanic eruption, then was struck by the same lightning that ended the eruption. The dual energies of fire and storm are locked within, released only through precise spellwork. The staff hums when rain is approaching.',
    price: 34200,
    currency: 'Gold',
    stats: { 'Spell Power': '763', 'Fire Bonus': '+28%', 'Storm Bonus': '+28%', 'Cast Speed': '+15%' },
  },
  {
    id: 10,
    name: 'Hollow Fang',
    type: 'weapon',
    rarity: 'rare',
    shortDescription: 'Channels toxin through its blade. One cut is enough.',
    description: 'Crafted from the hollowed fang of a black serpent, this dagger features internal channels that carry poison from a reservoir in the hilt directly to the tip. Favored by assassins who prefer not to wait for a second opening. Refill poison separately — not included.',
    price: 11400,
    currency: 'Gold',
    stats: { 'Attack Power': '380', 'Poison Damage': '45/sec', 'Poison Duration': '12 sec', 'Critical Strike': '+16%' },
  },
  {
    id: 11,
    name: 'Silvershadow Stallion',
    type: 'mount',
    rarity: 'legendary',
    shortDescription: 'Runs through moonlight. Faster after dark.',
    description: 'This ethereal stallion exists partially in the spirit realm. During the day it moves like any exceptional horse; at night, it partially dematerializes, allowing it to pass through minor obstacles and move at supernatural speed. It does not eat grain. What it eats is unclear.',
    price: 89000,
    currency: 'Gold',
    stats: { 'Move Speed': '+180%', 'Night Speed': '+240%', 'Phase Ability': 'Active', 'Stamina': 'Unlimited' },
  },
  {
    id: 12,
    name: 'Emberclaw Wyrmling',
    type: 'pet',
    rarity: 'epic',
    shortDescription: 'A juvenile fire drake. Already dangerously opinionated.',
    description: 'Hatched from a clutch of eggs found in an abandoned volcanic nest, this wyrmling has been socialized — mostly. It will fight loyally alongside its owner and occasionally set things on fire without being asked. Treat it with respect. It has a long memory and short patience.',
    price: 42000,
    currency: 'Gold',
    stats: { 'Fire Breath': '120 dmg/sec', 'Bite': '280 dmg', 'Loyalty': 'Fierce', 'Heat Aura': '+15 fire res' },
  },
]

export default items
